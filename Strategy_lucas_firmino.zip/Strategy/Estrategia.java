package Strategy;

// Definição da interface estrategia

public interface Estrategia {
    void executar(); 
}
